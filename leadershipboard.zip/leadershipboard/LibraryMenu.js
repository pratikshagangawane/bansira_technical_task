class LibraryMenu {
    constructor(library) {
        this.library = library;
    }

    displayMenu() {
        console.log("Welcome to the Library Menu!");
        console.log("----------------------------");
        console.log("1. View Popular Departments");
        console.log("2. View Popular Books");
        console.log("3. Search for a Book");
        console.log("4. Exit");
        console.log("----------------------------");
    }

    handleInput(input) {
        switch (input) {
            case "1":
                this.viewPopularDepartments();
                break;
            case "2":
                this.viewPopularBooks();
                break;
            case "3":
                this.searchForBook();
                break;
            case "4":
                console.log("Goodbye!");
                process.exit(0);
                break;
            default:
                console.log("Invalid input. Please try again.");
                this.displayMenu();
        }
    }

    viewPopularDepartments() {
        console.log("Popular Departments:");
        console.log("--------------------");
        this.library.departmentRanking.top5Departments.forEach((department, index) => {
            console.log(`${index + 1}. ${department.name} - ${department.downloads} downloads`);
        });
        this.displayMenu();
    }

    viewPopularBooks() {
        console.log("Popular Books:");
        console.log("------------");
        this.library.bookRanking.weeklyPopularBooks.forEach((book, index) => {
            console.log(`${index + 1}. ${book.title} - ${book.downloads} downloads`);
        });
        this.displayMenu();
    }

    searchForBook() {
        console.log("Search for a Book:");
        console.log("---------------");
        const readline = require("readline");
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        rl.question("Enter book title: ", (title) => {
            const book = this.library.books.find((book) => book.title === title);
            if (book) {
                console.log(`Book found: ${book.title} - ${book.downloads} downloads`);
            } else {
                console.log("Book not found.");
            }
            rl.close();
            this.displayMenu();
        });
    }
}

module.exports = LibraryMenu;