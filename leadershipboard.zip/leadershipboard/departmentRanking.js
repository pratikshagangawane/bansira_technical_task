// departmentRanking.js
const departments = [
    { name: 'Computer Science', downloads: 0 },
    { name: 'Mathematics', downloads: 0 },
    { name: 'Physics', downloads: 0 },
    { name: 'Biology', downloads: 0 },
    { name: 'Chemistry', downloads: 0 },
];

let lastWeekWinner = null;
let top5Departments = [];

function updateDepartmentRanking() {
    // Update downloads for each department
    departments.forEach((department) => {
        department.downloads += Math.floor(Math.random() * 10); // simulate downloads
    });

    // Calculate top 5 departments
    top5Departments = departments.sort((a, b) => b.downloads - a.downloads).slice(0, 5);

    // Update last week winner
    lastWeekWinner = top5Departments[0].name;

    console.log(`Last week winner: ${lastWeekWinner}`);
    console.log(`Top 5 departments: ${top5Departments.map((department) => department.name).join(', ')}`);
}

// Update department ranking every day
setInterval(updateDepartmentRanking, 24 * 60 * 60 * 1000); // 1 day

// Initial update
updateDepartmentRanking();