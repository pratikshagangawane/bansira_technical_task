// index.js
const LibraryMenu = require('./LibraryMenu');

module.exports = LibraryMenu;