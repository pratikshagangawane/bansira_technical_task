import java.util.List;
import java.util.Scanner;

public class LibraryMenu {
    private static Library library;
    private static Scanner scanner;

    public LibraryMenu(Library library) {
        LibraryMenu.library = library;
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        Library library = new Library();
        LibraryMenu menu = new LibraryMenu(library);
        menu.start();
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            System.out.println("Library Menu:");
            System.out.println("1. Add book");
            System.out.println("2. Remove book");
            System.out.println("3. Find book by title");
            System.out.println("4. Find book by author");
            System.out.println("5. List all books");
            System.out.println("6. List available books");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    findBookByTitle();
                    break;
                case 4:
                    findBookByAuthor();
                    break;
                case 5:
                    listAllBooks();
                    break;
                case 6:
                    listAvailableBooks();
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void addBook() {
        System.out.print("Enter book title: ");
        String title = scanner.next();
        System.out.print("Enter book author: ");
        String author = scanner.next();
        System.out.print("Enter book ISBN: ");
        String isbn = scanner.next();
        System.out.print("Enter book genre: ");
        String genre = scanner.next();
        System.out.print("Enter book departments: ");
        String department = scanner.next();
        System.out.print("Enter book publication year: ");
        int publicationYear = scanner.nextInt();
        System.out.print("Is the book available? (true/false): ");
        boolean availability = scanner.nextBoolean();

        Book book = new Book(title, author, isbn, genre, publicationYear, department, availability);
        library.addBook(book);
        System.out.println("Book added successfully!");
    }

    private static void removeBook() {
        System.out.print("Enter the ISBN of the book to remove: ");
        String isbn = scanner.next();
        try {
            library.removeBook(isbn);
            System.out.println("Book removed successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println("Book not found in the library.");
        }
    }

    private static void findBookByTitle() {
        System.out.print("Enter the title of the book to search: ");
        String title = scanner.next();
        List<Book> result = library.findBookByTitle(title);
        if (result.isEmpty()) {
            System.out.println("No books found with the given title.");
        } else {
            System.out.println("Books found with the given title:");
            for (Book book : result) {
                System.out.println(book.getTitle() + " by " + book.getAuthor());
            }
        }
    }

    private static void findBookByAuthor() {
        System.out.print("Enter the author of the bookto search: ");
        String author = scanner.next();
        List<Book> result = library.findBookByAuthor(author);
        if (result.isEmpty()) {
            System.out.println("No books found by the given author.");
        } else {
            System.out.println("Books found by the given author:");
            for (Book book : result) {
                System.out.println(book.getTitle());
            }
        }
    }

    private static void listAllBooks() {
        List<Book> books = library.listAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            System.out.println("All books in the library:");
            for (Book book : books) {
                System.out.println(book.getTitle() + " by " + book.getAuthor());
            }
        }
    }

    private static void listAvailableBooks() {
        List<Book> books = library.listAvailableBooks();
        if (books.isEmpty()) {
            System.out.println("No available books in the library.");
        } else {
            System.out.println("Available books in the library:");
            for (Book book : books) {
                System.out.println(book.getTitle() + " by " + book.getAuthor());
            }
        }
    }

}
