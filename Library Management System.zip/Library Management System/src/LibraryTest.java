import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class LibraryTest {
    @Test
    public void testAddBook() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        assertTrue(library.listAllBooks().size() == 1);
    }

    @Test
    public void testAddDuplicateBook() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        try {
            library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
            fail("Expected an exception for adding a duplicate book.");
        } catch (IllegalArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testRemoveBook() {
        Library library =new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        library.removeBook("1234567890");
        assertTrue(library.listAllBooks().size() == 0);
    }

    @Test
    public void testRemoveNonExistentBook() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        try {
            library.removeBook("0987654321");
            fail("Expected an exception for removing a non-existent book.");
        } catch (IllegalArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testFindBookByTitle() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "0987654321", "Fiction", 1960, "Fiction Department", true));
        List<Book> result = library.findBookByTitle("the catcher in the rye");
        assertEquals(result.size(), 1);
        assertEquals(result.get(0).getTitle(), "The Catcher in the Rye");
    }

    @Test
    public void testFindBookByAuthor() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        library.addBook(new Book("Franny and Zooey", "J.D. Salinger", "0987654321", "Fiction", 1961, "Fiction Department", true));
        List<Book> result = library.findBookByAuthor("j.d. salinger");
        assertEquals(result.size(), 2);
        assertTrue(result.stream().anyMatch(book -> book.getTitle().equals("The Catcher in the Rye")));
        assertTrue(result.stream().anyMatch(book -> book.getTitle().equals("Franny and Zooey")));
    }

    @Test
    public void testListAllBooks() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "0987654321", "Fiction", 1960, "Fiction Department", true));
        List<Book> result = library.listAllBooks();
        assertEquals(result.size(), 2);
        assertTrue(result.stream().anyMatch(book -> book.getTitle().equals("The Catcher in the Rye")));
        assertTrue(result.stream().anyMatch(book -> book.getTitle().equals("To Kill a Mockingbird")));
    }

    @Test
    public void testListAvailableBooks() {
        Library library = new Library();
        library.addBook(new Book("The Catcher in the Rye", "J.D. Salinger", "1234567890", "Fiction", 1951, "Fiction Department", true));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "0987654321", "Fiction", 1960, "Fiction Department", false));
        List<Book> result = library.listAvailableBooks();
        assertEquals(result.size(), 1);
        assertTrue(result.stream().anyMatch(book -> book.getTitle().equals("The Catcher in the Rye")));
    }
}
