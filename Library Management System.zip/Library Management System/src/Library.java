import java.util.*;

public class Library {
    private Map<String, List<Book>> departments;

    public Library() {
        departments = new HashMap<>();
    }

    public void addBook(Book book) {
        String departmentName = book.getGenre();
        if (!departments.containsKey(departmentName)) {
            departments.put(departmentName, new ArrayList<>());
        }
        List<Book> books = departments.get(departmentName);
        for (Book b : books) {
            if (b.getIsbn().equals(book.getIsbn())) {
                throw new IllegalArgumentException("Book already exists in the library.");
            }
        }
        books.add(book);
    }

    public void removeBook(String isbn) {
        for (List<Book> books : departments.values()) {
            Iterator<Book> iterator = books.iterator();
            while (iterator.hasNext()) {
                Book book = iterator.next();
                if (book.getIsbn().equals(isbn)) {
                    iterator.remove();
                    return;
                }
            }
        }
        throw new IllegalArgumentException("Book not found in the library.");
    }

    public List<Book> findBookByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (List<Book> books : departments.values()) {
            for (Book book : books) {
                if (book.getTitle().equalsIgnoreCase(title)) {
                    result.add(book);
                }
            }
        }
        return result;
    }

    public List<Book> findBookByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (List<Book> books : departments.values()) {
            for (Book book : books) {
                if (book.getAuthor().equalsIgnoreCase(author)) {
                    result.add(book);
                }
            }
        }
        return result;
    }

    public List<Book> listAllBooks() {
        List<Book> result = new ArrayList<>();
        for (List<Book> books : departments.values()) {
            result.addAll(books);
        }
        return result;
    }

    public List<Book> listAvailableBooks() {
        List<Book> result = new ArrayList<>();
        for (List<Book> books : departments.values()) {
            for (Book book : books) {
                if (book.getAvailability()) {
                    result.add(book);
                }
            }
        }
        return result;
    }

}
